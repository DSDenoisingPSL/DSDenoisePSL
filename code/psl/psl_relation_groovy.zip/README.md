# Noise Reduction in Distant Supervision for Relation Extraction using Probabilistic Soft Logic
This repository contains the source code for the  *[Noise Reduction in Distant Supervision for
Relation Extraction using Probabilistic Soft Logic]*.

**Task**:



### Data
To run experiments unzip psl_predicates.zip to folder 'data'. After that there are should be three folders for each dataset.
 
